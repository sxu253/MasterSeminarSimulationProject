import matplotlib
import matplotlib.pyplot as plt
plt.style.use('fivethirtyeight')
import warnings
warnings.simplefilter('ignore', FutureWarning)
import numpy as np
import pandas as pd
import seaborn as sns
import pylab as plt

def LoanAmount_Size_Time():
    bubbleSort = pd.read_csv('LoanAmount_Size_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('LoanAmount_Size_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('LoanAmount_Size_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('LoanAmount_Size_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('LoanAmount_Size_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Loan Amount Time by Size',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('LoanAmount_Size_Time.png')
    plt.show()

def LoanAmount_Size_Memory():
    bubbleSort = pd.read_csv('LoanAmount_Size_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('LoanAmount_Size_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('LoanAmount_Size_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('LoanAmount_Size_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('LoanAmount_Size_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Loan Amount Memory by Size',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('LoanAmount_Size_Memory.png')
    plt.show()

def LoanAmount_Sortedness_Memory():
    bubbleSort = pd.read_csv('LoanAmount_Sortedness_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('LoanAmount_Sortedness_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('LoanAmount_Sortedness_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('LoanAmount_Sortedness_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('LoanAmount_Sortedness_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Loan Amount Memory by Sortedness',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('LoanAmount_Sortedness_Memory.png')
    plt.show()

def LoanAmount_Sortedness_Memory_Inplace():
    bubbleSort = pd.read_csv('LoanAmount_Sortedness_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('LoanAmount_Sortedness_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    selectionSort = pd.read_csv('LoanAmount_Sortedness_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    plt.title('Loan Amount Memory by Sortedness',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('LoanAmount_Sortedness_Memory_Inplace.png')
    plt.show()

def LoanAmount_Sortedness_Time():
    bubbleSort = pd.read_csv('LoanAmount_Sortedness_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('LoanAmount_Sortedness_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('LoanAmount_Sortedness_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('LoanAmount_Sortedness_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('LoanAmount_Sortedness_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Loan Amount Time by Sortedness',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('LoanAmount_Sortedness_Time.png')
    plt.show()

def MovieRatings_Size_Memory():
    bubbleSort = pd.read_csv('MovieRatings_Size_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('MovieRatings_Size_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('MovieRatings_Size_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('MovieRatings_Size_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('MovieRatings_Size_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Movie Ratings Memory by Size',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('MovieRatings_Size_Memory.png')
    plt.show()

def MovieRatings_Size_Memory_NoQuick():
    bubbleSort = pd.read_csv('MovieRatings_Size_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('MovieRatings_Size_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('MovieRatings_Size_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    selectionSort = pd.read_csv('MovieRatings_Size_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    plt.title('Movie Ratings Memory by Size',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('MovieRatings_Size_Memory_NoQuick.png')
    plt.show()

def MovieRatings_Sortedness_Memory():
    bubbleSort = pd.read_csv('MovieRatings_Sortedness_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('MovieRatings_Sortedness_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('MovieRatings_Sortedness_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('MovieRatings_Sortedness_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('MovieRatings_Sortedness_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Movie Ratings Memory by Sortedness',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('MovieRatings_Sortedness_Memory.png')
    plt.show()

def MovieRatings_Sortedness_Memory_NoQuick():
    bubbleSort = pd.read_csv('MovieRatings_Sortedness_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('MovieRatings_Sortedness_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('MovieRatings_Sortedness_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    selectionSort = pd.read_csv('MovieRatings_Sortedness_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    plt.title('Movie Ratings Memory by Sortedness',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('MovieRatings_Sortedness_Memory_NoQuick.png')
    plt.show()

def MovieRatings_Size_Time():
    bubbleSort = pd.read_csv('MovieRatings_Size_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('MovieRatings_Size_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('MovieRatings_Size_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('MovieRatings_Size_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('MovieRatings_Size_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Movie Ratings Time by Size',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('MovieRatings_Size_Time.png')
    plt.show()

def MovieRatings_Sortedness_Time():
    bubbleSort = pd.read_csv('MovieRatings_Sortedness_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('MovieRatings_Sortedness_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('MovieRatings_Sortedness_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('MovieRatings_Sortedness_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('MovieRatings_Sortedness_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Movie Ratings Time by Size',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('MovieRatings_Sortedness_Time.png')
    plt.show()

def Synthetic_Size_Memory():
    bubbleSort = pd.read_csv('Synthetic_Size_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic_Size_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic_Size_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic_Size_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic_Size_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #1 Memory by Size',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic_Size_Memory.png')
    plt.show()

def Synthetic_Size_Time():
    bubbleSort = pd.read_csv('Synthetic_Size_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic_Size_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic_Size_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic_Size_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic_Size_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #1 Time by Size',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic_Size_Time.png')
    plt.show()

def Synthetic_Sortedness_Memory():
    bubbleSort = pd.read_csv('Synthetic_Sortedness_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic_Sortedness_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic_Sortedness_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic_Sortedness_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic_Sortedness_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #1 Memory by Sortedness',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic_Sortedness_Memory.png')
    plt.show()

def Synthetic_Sortedness_Time():
    bubbleSort = pd.read_csv('Synthetic_Sortedness_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic_Sortedness_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic_Sortedness_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic_Sortedness_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic_Sortedness_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #1 Time by Size',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic_Sortedness_Time.png')
    plt.show()

def Synthetic2_Sortedness_Time():
    bubbleSort = pd.read_csv('Synthetic2_Sortedness_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic2_Sortedness_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic2_Sortedness_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic2_Sortedness_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic2_Sortedness_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #2 Time by Sortedness',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic2_Sortedness_Time.png')
    plt.show()

def Synthetic2_Sortedness_Memory():
    bubbleSort = pd.read_csv('Synthetic2_Sortedness_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 0)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic2_Sortedness_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 0)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic2_Sortedness_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 0)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic2_Sortedness_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 0)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic2_Sortedness_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 0)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #2 Memory by Sortedness',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Sortedness',size=20)
    plt.legend(prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/30),fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic2_Sortedness_Memory.png')
    plt.show()

def Synthetic2_Size_Time():
    bubbleSort = pd.read_csv('Synthetic2_Size_Time_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic2_Size_Time_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic2_Size_Time_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic2_Size_Time_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic2_Size_Time_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #2 Time by Size',size=26)
    plt.ylabel('Time (Seconds)',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic2_Size_Time.png')
    plt.show()

def Synthetic2_Size_Memory():
    bubbleSort = pd.read_csv('Synthetic2_Size_Memory_Bubble.csv')
    bubbleMean = bubbleSort.mean(axis = 1)
    bubbleMeanX = bubbleMean.index

    insertionSort = pd.read_csv('Synthetic2_Size_Memory_Insertion.csv')
    insertionMean = insertionSort.mean(axis = 1)
    insertionMeanX = insertionMean.index

    mergeSort = pd.read_csv('Synthetic2_Size_Memory_Merge.csv')
    mergeMean = mergeSort.mean(axis = 1)
    mergeMeanX = mergeMean.index

    quickSort = pd.read_csv('Synthetic2_Size_Memory_Quick.csv')
    quickMean = quickSort.mean(axis = 1)
    quickMeanX = quickMean.index

    selectionSort = pd.read_csv('Synthetic2_Size_Memory_Selection.csv')
    selectionMean = selectionSort.mean(axis = 1)
    selectionMeanX = selectionMean.index

    fig1 = plt.figure(figsize=(30,15))
    ax1 = fig1.add_subplot(111)
    ax1.scatter(selectionMean.index, selectionMean,s=50 ,c='b', label='Selection')
    ax1.scatter(bubbleMean.index, bubbleMean,s=50  ,c='r', label='Bubble')
    ax1.scatter(insertionMean.index, insertionMean,s=50 ,c='g', label='Insertion')
    ax1.scatter(mergeMean.index, mergeMean,s=50  ,c='y', label='Merge')
    ax1.scatter(quickMean.index, quickMean, c='k', label='Quick')
    plt.title('Synthetic #2 Memory by Size',size=26)
    plt.ylabel('Memory Blocks',size=20)
    plt.xlabel('Size',size=20)
    plt.legend(loc=2, prop={'size': 20})
    plt.xticks(np.arange(0, len(selectionMean), len(selectionMean)/10), ['0','1000','2000','3000','4000','5000','6000','7000','8000','9000','10000'], fontsize=18)
    plt.yticks(fontsize=18)
    plt.savefig('Synthetic2_Size_Memory.png')
    plt.show()

