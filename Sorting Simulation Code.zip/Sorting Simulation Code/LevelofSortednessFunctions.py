import numpy as np
import pandas as pd
import seaborn as sns
import csv
import time
import tracemalloc
from scipy import stats
import SortingFunctions as sort
import Helpers as helpers
import datetime as dt
import sys


def sortednessMeasure(array, sortedArray, measurementType, sortType, Outputfile): 
    increment = .01
    prevSorteness = -1
    t = []
    df = pd.DataFrame()
    for i in range(1, len(array)):   
                rho, pvalue = stats.spearmanr(array, sortedArray)
                sortedness = round(rho, 2)
                if (sortedness >= prevSorteness+increment):                  
                    if measurementType == 1:
                        t = TakeTimeMeasurement(array, t, sortType)
                    if measurementType == 2:
                        t = TakeMemoryMeasurement(array, t, sortType)
                    df[sortedness] = t
                    if (sortedness == 1):
                        break
                    prevSorteness = sortedness
                item = array[i]
                j = i-1
                while j >= 0 and item < array[j]: 
                        array[j+1] = array[j] 
                        j -= 1
                array[j+1] = item 

    df.to_csv(index=False, sep=",", path_or_buf=Outputfile) 

        

def TakeTimeMeasurement(array, t, sortType):
    t = []   
    for y in range(5):
        arrayMeasure = array.copy()
        startTime = time.time()
        if sortType == 1:
         sort.selectionSort(arrayMeasure)
        if sortType == 2:
         sort.insertionSort(arrayMeasure)
        if sortType == 3:
          sort.bubbleSort(arrayMeasure)
        if sortType == 4:
         sort.mergeSort(arrayMeasure)
        if sortType == 5:
         sort.quickSort(arrayMeasure, 0, len(arrayMeasure)-1)
        endTime = time.time()
        t.append(endTime - startTime)
    return t


def TakeMemoryMeasurement(array, t, sortType):
    t = []
    for y in range(5):
        arrayMeasure = array.copy()
        tracemalloc.start()
        if sortType == 1:
         sort.selectionSort(arrayMeasure)
        if sortType == 2:
         sort.insertionSort(arrayMeasure)
        if sortType == 3:
          sort.bubbleSort(arrayMeasure)
        if sortType == 4:
          sort.mergeSort(arrayMeasure)
        if sortType == 5:
          sort.quickSort(arrayMeasure, 0, len(arrayMeasure)-1)
        cur, peak = tracemalloc.get_traced_memory()
        t.append(peak)
        tracemalloc.stop()
    return t

sys.setrecursionlimit(10**6) 
array = []
filename = 'LoanAmountShort.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

array = sort.quickSort(array, 0, len(array)-1)
reverseSorted = array.copy();
reverseSorted.reverse();

sortednessMeasure(reverseSorted.copy(), array, 1,1, "LoanAmount_Sortedness_Time_Selection.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,2, "LoanAmount_Sortedness_Time_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,3, "LoanAmount_Sortedness_Time_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,4, "LoanAmount_Sortedness_Time_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,5, "LoanAmount_Sortedness_Time_Quick.csv")

sortednessMeasure(reverseSorted.copy(), array, 2,1, "LoanAmount_Sortedness_Memory_Selection.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,2, "LoanAmount_Sortedness_Memory_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,3, "LoanAmount_Sortedness_Memory_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,4, "LoanAmount_Sortedness_Memory_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,5, "LoanAmount_Sortedness_Memory_Quick.csv")

array = []
filename = 'mratingshort.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

array = sort.quickSort(array, 0, len(array)-1)
reverseSorted = array.copy();
reverseSorted.reverse();

sortednessMeasure(reverseSorted.copy(), array, 1,1, "MovieRatings_Sortedness_Time_Selection.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,2, "MovieRatings_Sortedness_Time_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,3, "MovieRatings_Sortedness_Time_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,4, "MovieRatings_Sortedness_Time_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,5, "MovieRatings_Sortedness_Time_Quick.csv")

sortednessMeasure(reverseSorted.copy(), array, 2,1, "MovieRatings_Sortedness_Memory_Selection.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,2, "MovieRatings_Sortedness_Memory_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,3, "MovieRatings_Sortedness_Memory_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,4, "MovieRatings_Sortedness_Memory_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,5, "MovieRatings_Sortedness_Memory_Quick.csv")

array = []
sys.setrecursionlimit(10**6) 
filename = 'Synthetic1_2000.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

array = sort.quickSort(array, 0, len(array)-1)
reverseSorted = array.copy();
reverseSorted.reverse();

sortednessMeasure(reverseSorted.copy(), array, 1,1, "Synthetic_Sortedness_Time_Selection.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,2, "Synthetic_Sortedness_Time_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,3, "Synthetic_Sortedness_Time_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,4, "Synthetic_Sortedness_Time_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,5, "Synthetic_Sortedness_Time_Quick.csv")

sortednessMeasure(reverseSorted.copy(), array, 2,1, "Synthetic_Sortedness_Memory_Selection")
sortednessMeasure(reverseSorted.copy(), array, 2,2, "Synthetic_Sortedness_Memory_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,3, "Synthetic_Sortedness_Memory_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,4, "Synthetic_Sortedness_Memory_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,5, "Synthetic_Sortedness_Memory_Quick.csv")

array = []
sys.setrecursionlimit(10**6) 
filename = 'Synthetic2_2000.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

array = sort.quickSort(array, 0, len(array)-1)
reverseSorted = array.copy();
reverseSorted.reverse();


sortednessMeasure(reverseSorted.copy(), array, 1,1, "Synthetic2_Sortedness_Time_Selection.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,2, "Synthetic2_Sortedness_Time_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,3, "Synthetic2_Sortedness_Time_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,4, "Synthetic2_Sortedness_Time_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 1,5, "Synthetic2_Sortedness_Time_Quick.csv")

sortednessMeasure(reverseSorted.copy(), array, 2,1, "Synthetic2_Sortedness_Memory_Selection")
sortednessMeasure(reverseSorted.copy(), array, 2,2, "Synthetic2_Sortedness_Memory_Insertion.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,3, "Synthetic2_Sortedness_Memory_Bubble.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,4, "Synthetic2_Sortedness_Memory_Merge.csv")
sortednessMeasure(reverseSorted.copy(), array, 2,5, "Synthetic2_Sortedness_Memory_Quick.csv")