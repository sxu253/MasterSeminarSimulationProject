import csv
import time
import tracemalloc
from scipy import stats
import SortingFunctions as sort
import Helpers as helpers
import pandas as pd
import sys


def runMemoryInsertionSort(outputfileName, array):
    memory = [];
    for x in range(len(array)):       
        m = []
        for y in range(5):
            arraytoSort = array[:x]
            tracemalloc.start()
            sort.insertionSort(arraytoSort)
            cur, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            m.append(peak)
            memory.append(m)

    df =  pd.DataFrame(data=memory, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)


def runMemorySelectionSort(outputfileName, array):
    memory = [];
    for x in range(len(array)):       
        m = []
        for y in range(5):
            arraytoSort = array[:x]
            tracemalloc.start()
            sort.selectionSort(arraytoSort)
            cur, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            m.append(peak)
            memory.append(m)

    df =  pd.DataFrame(data=memory, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)

def runMemoryBubbleSort(outputfileName, array):
    memory = [];
    for x in range(len(array)):       
        m = []
        for y in range(5):
            arraytoSort = array[:x]
            tracemalloc.start()
            sort.bubbleSort(arraytoSort)
            cur, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            m.append(peak)
            memory.append(m)

    df =  pd.DataFrame(data=memory, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)

def runMemoryMergeSort(outputfileName, array):
    memory = [];
    for x in range(len(array)):      
        m = []
        for y in range(5):
            arraytoSort = array[:x]
            tracemalloc.start()
            sort.mergeSort(arraytoSort)
            cur, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            m.append(peak)
            memory.append(m)

    df =  pd.DataFrame(data=memory, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)

def runMemoryQuickSort(outputfileName, array):
    memory = [];
    for x in range(len(array)):      
        m = []
        for y in range(5):
            arraytoSort = array[:x]
            tracemalloc.start()
            sort.quickSort(arraytoSort, 0, len(arraytoSort)-1)
            cur, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            m.append(peak)
            memory.append(m)

    df =  pd.DataFrame(data=memory, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)

sys.setrecursionlimit(10**6) 
filename = 'Synthetic1_2000.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]


runMemoryMergeSort("Synthetic_Size_Memory_Merge.csv", array)
runMemoryQuickSort("Synthetic_Size_Memory_Quick.csv",array)
runMemoryInsertionSort("Synthetic_Size_Memory_Insertion.csv",array)
runMemorySelectionSort("Synthetic_Size_Memory_Selection.csv",array)
runMemoryBubbleSort("Synthetic_Size_Memory_Bubble.csv",array)

array = []
filename = 'LoanAmountShort.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

runMemoryMergeSort("LoanAmount_Size_Memory_Merge.csv",array)
runMemoryQuickSort("LoanAmount_Size_Memory_Quick.csv",array)
runMemoryInsertionSort("LoanAmount_Size_Memory_Insertion.csv",array)
runMemorySelectionSort("LoanAmount_Size_Memory_Selection.csv",array)
runMemoryBubbleSort("LoanAmount_Size_Memory_Bubble.csv",array)


filename = 'Synthetic2_2000.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]


runMemoryMergeSort("Synthetic2_Size_Memory_Merge.csv", array)
runMemoryQuickSort("Synthetic2_Size_Memory_Quick.csv",array)
runMemoryInsertionSort("Synthetic2_Size_Memory_Insertion.csv",array)
runMemorySelectionSort("Synthetic2_Size_Memory_Selection.csv",array)
runMemoryBubbleSort("Synthetic2_Size_Memory_Bubble.csv",array)


array = []
filename = 'mratingshort.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

runMemoryMergeSort("MovieRatings_Size_Memory_Merge.csv",array)
runMemoryQuickSort("MovieRatings_Size_Memory_Quick.csv",array)
runMemoryInsertionSort("MovieRatings_Size_Memory_Insertion.csv",array)
runMemorySelectionSort("MovieRatings_Size_Memory_Selection.csv",array)
runMemoryBubbleSort("MovieRatings_Size_Memory_Bubble.csv",array)

