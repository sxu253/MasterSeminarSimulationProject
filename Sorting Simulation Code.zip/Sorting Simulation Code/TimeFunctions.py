
import numpy as np
import pandas as pd
import seaborn as sns
import csv
import time
import tracemalloc
from scipy import stats
import Helpers as helpers
import SortingFunctions as sort
import sys

def runQuickSort(outputfileName, array):
    times = [];
    for x in range(len(array)):   
        t = []
        for y in range(5):
            arraytoSort = array[:x]
            startTime = time.time()
            sort.quickSort(arraytoSort, 0, len(arraytoSort)-1)
            endTime = time.time()
            t.append(endTime - startTime)
            times.append(t)

    df =  pd.DataFrame(data=times, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)


def runInsertionSort(outputfileName, array):
    times = [];
    for x in range(len(array)):   
        t = []
        for y in range(5):
            arraytoSort = array[:x]
            startTime = time.time()
            sort.insertionSort(arraytoSort)
            endTime = time.time()
            t.append(endTime - startTime)
            times.append(t)

    df =  pd.DataFrame(data=times, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)


def runSelectionSort(outputfileName, array):
    times = [];
    for x in range(len(array)):   
        t = []
        for y in range(5):
            arraytoSort = array[:x]
            startTime = time.time()
            sort.selectionSort(arraytoSort)
            endTime = time.time()
            t.append(endTime - startTime)
            times.append(t)

    df =  pd.DataFrame(data=times, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)


def runBubbleSort(outputfileName, array):
    times = [];
    for x in range(len(array)):   
        t = []
        for y in range(5):
            arraytoSort = array[:x]
            startTime = time.time()
            sort.bubbleSort(arraytoSort)
            endTime = time.time()
            t.append(endTime - startTime)
            times.append(t)

    df =  pd.DataFrame(data=times, columns= ['1', '2', '3', '4', '5'])
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)



def runMergeSort(outputfileName, array):
    times = [];
    for x in range(len(array)):   
        t = []
        for y in range(5):
            arraytoSort = array[:x]
            startTime = time.time()
            sort.mergeSort(arraytoSort)
            endTime = time.time()
            t.append(endTime - startTime)
            times.append(t)

    df =  pd.DataFrame(data=times, columns= ['1', '2', '3', '4', '5'])
    df =  pd.DataFrame(data=times)
    df.to_csv(index=False, sep=",", path_or_buf=outputfileName)


sys.setrecursionlimit(10**6) 
filename = 'Synthetic1_2000.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

runMergeSort("Synthetic_Size_Time_Merge.csv", array)
runQuickSort("Synthetic_Size_Time_Quick.csv",array)
runInsertionSort("Synthetic_Size_Time_Insertion.csv",array)
runSelectionSort("Synthetic_Size_Time_Selection.csv",array)
runBubbleSort("Synthetic_Size_Time_Bubble.csv",array)

array = []
filename = 'LoanAmountShort.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

runMergeSort("LoanAmount_Size_Time_Merge.csv",array)
runQuickSort("LoanAmount_Size_Time_Quick.csv",array)
runInsertionSort("LoanAmount_Size_Time_Insertion.csv",array)
runSelectionSort("LoanAmount_Size_Time_Selection.csv",array)
runBubbleSort("LoanAmount_Size_time_Bubble.csv",array)


filename = 'Synthetic2_2000.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

runMergeSort("Synthetic2_Size_Time_Merge.csv", array)
runQuickSort("Synthetic2_Size_Time_Quick.csv",array)
runInsertionSort("Synthetic2_Size_Time_Insertion.csv",array)
runSelectionSort("Synthetic2_Size_Time_Selection.csv",array)
runBubbleSort("Synthetic2_Size_Time_Bubble.csv",array)

array = []
filename = 'mratingshort.csv' 
with open(filename, newline='') as f:
    reader = csv.reader(f, delimiter=',')
    array = [int(row[0]) for row in reader]

runMergeSort("MovieRatings_Size_Time_Merge.csv",array)
runQuickSort("MovieRatings__Size_Time_Quick.csv",array)
runInsertionSort("MovieRatings__Size_Time_Insertion.csv",array)
runSelectionSort("MovieRatings__Size_Time_Selection.csv",array)
runBubbleSort("MovieRatings__Size_time_Bubble.csv",array)